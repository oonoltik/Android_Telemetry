package com.alex.android_telemetry.telemetry.api.mapper

import com.alex.android_telemetry.telemetry.api.model.DeviceStateBatchPayload
import com.alex.android_telemetry.telemetry.api.model.HeadingBatchPayload
import com.alex.android_telemetry.telemetry.api.model.NetworkBatchPayload
import com.alex.android_telemetry.telemetry.api.model.TelemetryBatchPayload

class TelemetryBatchPayloadMapper(
    private val sampleMapper: TelemetrySamplePayloadMapper,
    private val eventMapper: TelemetryEventPayloadMapper,
    private val appInfoProvider: AppInfoProvider,
) {

    fun map(batch: CurrentTelemetryBatch): TelemetryBatchPayload {
        return TelemetryBatchPayload(
            deviceId = batch.deviceId,
            driverId = batch.driverId,
            sessionId = batch.sessionId,
            timestamp = batch.timestampIso,
            appVersion = appInfoProvider.appVersion(),
            appBuild = appInfoProvider.appBuild(),
            iosVersion = appInfoProvider.osVersion(),
            deviceModel = appInfoProvider.deviceModel(),
            locale = appInfoProvider.locale(),
            timezone = appInfoProvider.timezone(),
            trackingMode = batch.trackingMode.toWireValue(),
            transportMode = batch.transportMode?.toWireValue(),
            batchId = batch.batchId,
            batchSeq = batch.batchSeq,
            samples = batch.samples.map(sampleMapper::map),
            events = batch.events.map(eventMapper::map),
            deviceState = batch.deviceState?.let(::mapDeviceState),
            network = batch.network?.let(::mapNetwork),
            heading = batch.heading?.let(::mapHeading),
        )
    }

    private fun mapDeviceState(state: CurrentDeviceState): DeviceStateBatchPayload {
        return DeviceStateBatchPayload(
            batteryLevel = state.batteryLevel,
            batteryState = state.batteryState?.toWireValue(),
            lowPowerMode = state.lowPowerMode,
        )
    }

    private fun mapNetwork(network: CurrentNetworkState): NetworkBatchPayload {
        return NetworkBatchPayload(
            status = network.status,
            interfaceName = network.interfaceName,
            expensive = network.expensive,
            constrained = network.constrained,
        )
    }

    private fun mapHeading(heading: CurrentHeadingState): HeadingBatchPayload {
        return HeadingBatchPayload(
            magneticDeg = heading.magneticDeg,
            trueDeg = heading.trueDeg,
            accuracyDeg = heading.accuracyDeg,
        )
    }
}

/**
 * Заменить на ваш реальный provider build/device metadata.
 */
interface AppInfoProvider {
    fun appVersion(): String?
    fun appBuild(): String?
    fun osVersion(): String?
    fun deviceModel(): String?
    fun locale(): String?
    fun timezone(): String?
}

/**
 * Заменить на ваш текущий batch/domain тип.
 *
 * Важно:
 * - timestampIso = batch timestamp в UTC ISO-8601
 * - samples = это то, что раньше было frames
 */
interface CurrentTelemetryBatch {
    val deviceId: String
    val driverId: String?
    val sessionId: String
    val timestampIso: String
    val trackingMode: CurrentTrackingMode
    val transportMode: CurrentTransportMode?
    val batchId: String
    val batchSeq: Int
    val samples: List<CurrentTelemetrySample>
    val events: List<CurrentTelemetryEvent>
    val deviceState: CurrentDeviceState?
    val network: CurrentNetworkState?
    val heading: CurrentHeadingState?
}

interface CurrentDeviceState {
    val batteryLevel: Double?
    val batteryState: CurrentBatteryState?
    val lowPowerMode: Boolean?
}

interface CurrentNetworkState {
    val status: String?
    val interfaceName: String?
    val expensive: Boolean?
    val constrained: Boolean?
}

interface CurrentHeadingState {
    val magneticDeg: Double?
    val trueDeg: Double?
    val accuracyDeg: Double?
}

enum class CurrentBatteryState {
    UNKNOWN,
    UNPLUGGED,
    CHARGING,
    FULL,
}

enum class CurrentTrackingMode {
    SINGLE_TRIP,
    DAY_MONITORING,
}

enum class CurrentTransportMode {
    CAR,
    BUS,
    METRO,
    PUBLIC_TRANSPORT,
    WALK,
    BIKE,
    UNKNOWN,
}

private fun CurrentBatteryState.toWireValue(): String {
    return when (this) {
        CurrentBatteryState.UNKNOWN -> "unknown"
        CurrentBatteryState.UNPLUGGED -> "unplugged"
        CurrentBatteryState.CHARGING -> "charging"
        CurrentBatteryState.FULL -> "full"
    }
}

private fun CurrentTrackingMode.toWireValue(): String {
    return when (this) {
        CurrentTrackingMode.SINGLE_TRIP -> "single_trip"
        CurrentTrackingMode.DAY_MONITORING -> "day_monitoring"
    }
}

private fun CurrentTransportMode.toWireValue(): String {
    return when (this) {
        CurrentTransportMode.CAR -> "car"
        CurrentTransportMode.BUS -> "bus"
        CurrentTransportMode.METRO -> "metro"
        CurrentTransportMode.PUBLIC_TRANSPORT -> "public_transport"
        CurrentTransportMode.WALK -> "walk"
        CurrentTransportMode.BIKE -> "bike"
        CurrentTransportMode.UNKNOWN -> "unknown"
    }
}