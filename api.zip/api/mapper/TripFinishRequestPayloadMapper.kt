package com.alex.android_telemetry.telemetry.api.mapper

import com.alex.android_telemetry.telemetry.api.model.ClientAggPayload
import com.alex.android_telemetry.telemetry.api.model.ClientTripMetricsPayload
import com.alex.android_telemetry.telemetry.api.model.DeviceMetaPayload
import com.alex.android_telemetry.telemetry.api.model.TripCorePayload
import com.alex.android_telemetry.telemetry.api.model.TripFinishRequestPayload
import com.alex.android_telemetry.telemetry.api.model.TripMetricsRawPayload

class TripFinishRequestPayloadMapper(
    private val appInfoProvider: AppInfoProvider,
) {

    fun map(finish: CurrentTripFinish): TripFinishRequestPayload {
        return TripFinishRequestPayload(
            sessionId = finish.sessionId,
            driverId = finish.driverId,
            deviceId = finish.deviceId,
            clientEndedAt = finish.clientEndedAtIso,
            tripCore = finish.tripId?.let {
                TripCorePayload(
                    tripId = it,
                    sessionId = finish.sessionId,
                    clientEndedAt = finish.clientEndedAtIso,
                )
            },
            deviceMeta = DeviceMetaPayload(
                platform = "Android",
                appVersion = appInfoProvider.appVersion(),
                appBuild = appInfoProvider.appBuild(),
                iosVersion = appInfoProvider.osVersion(),
                deviceModel = appInfoProvider.deviceModel(),
                locale = appInfoProvider.locale(),
                timezone = appInfoProvider.timezone(),
            ),
            trackingMode = finish.trackingMode.toWireValue(),
            transportMode = finish.transportMode?.toWireValue(),
            tripDurationSec = finish.tripDurationSec,
            finishReason = finish.finishReason,
            appVersion = appInfoProvider.appVersion(),
            appBuild = appInfoProvider.appBuild(),
            iosVersion = appInfoProvider.osVersion(),
            deviceModel = appInfoProvider.deviceModel(),
            locale = appInfoProvider.locale(),
            timezone = appInfoProvider.timezone(),
            clientMetrics = finish.clientMetrics?.let(::mapClientMetrics),
            tripMetricsRaw = finish.tripMetricsRaw?.let(::mapTripMetricsRaw),
        )
    }

    private fun mapClientMetrics(metrics: CurrentTripMetrics): ClientTripMetricsPayload {
        return ClientTripMetricsPayload(
            tripDistanceM = metrics.tripDistanceM,
            tripDistanceKmFromGps = metrics.tripDistanceKmFromGps,
            brake = mapAgg(metrics.brake),
            accel = mapAgg(metrics.accel),
            road = mapAgg(metrics.road),
            turn = mapAgg(metrics.turn),
        )
    }

    private fun mapTripMetricsRaw(metrics: CurrentTripMetrics): TripMetricsRawPayload {
        return TripMetricsRawPayload(
            tripDistanceM = metrics.tripDistanceM,
            tripDistanceKmFromGps = metrics.tripDistanceKmFromGps,
            brake = mapAgg(metrics.brake),
            accel = mapAgg(metrics.accel),
            turn = mapAgg(metrics.turn),
            road = mapAgg(metrics.road),
        )
    }

    private fun mapAgg(agg: CurrentAgg): ClientAggPayload {
        return ClientAggPayload(
            count = agg.count,
            sumIntensity = agg.sumIntensity,
            maxIntensity = agg.maxIntensity,
            countPerKm = agg.countPerKm,
            sumPerKm = agg.sumPerKm,
        )
    }
}

/**
 * Заменить на ваш finish/domain тип.
 */
interface CurrentTripFinish {
    val sessionId: String
    val driverId: String
    val deviceId: String
    val clientEndedAtIso: String
    val tripId: String?
    val trackingMode: CurrentTrackingMode
    val transportMode: CurrentTransportMode?
    val tripDurationSec: Double?
    val finishReason: String?
    val clientMetrics: CurrentTripMetrics?
    val tripMetricsRaw: CurrentTripMetrics?
}

interface CurrentTripMetrics {
    val tripDistanceM: Double
    val tripDistanceKmFromGps: Double
    val brake: CurrentAgg
    val accel: CurrentAgg
    val road: CurrentAgg
    val turn: CurrentAgg
}

interface CurrentAgg {
    val count: Int
    val sumIntensity: Double
    val maxIntensity: Double
    val countPerKm: Double
    val sumPerKm: Double
}