package com.alex.android_telemetry.telemetry.api.mapper

import com.alex.android_telemetry.telemetry.api.model.AccelPayload
import com.alex.android_telemetry.telemetry.api.model.AttitudePayload
import com.alex.android_telemetry.telemetry.api.model.RotationPayload
import com.alex.android_telemetry.telemetry.api.model.TelemetrySamplePayload

class TelemetrySamplePayloadMapper {

    fun map(sample: CurrentTelemetrySample): TelemetrySamplePayload {
        return TelemetrySamplePayload(
            t = sample.timestampIso,
            lat = sample.latitude,
            lon = sample.longitude,
            hAcc = sample.horizontalAccuracy,
            vAcc = sample.verticalAccuracy,
            speedMS = sample.speedMS,
            speedAcc = sample.speedAccuracy,
            course = sample.courseDeg,
            courseAcc = sample.courseAccuracyDeg,
            accel = mapAccel(sample),
            rotation = mapRotation(sample),
            attitude = mapAttitude(sample),
            aLongG = sample.aLongG,
            aLatG = sample.aLatG,
            aVertG = sample.aVertG,
        )
    }

    private fun mapAccel(sample: CurrentTelemetrySample): AccelPayload? {
        val x = sample.accelX ?: return null
        val y = sample.accelY ?: return null
        val z = sample.accelZ ?: return null
        return AccelPayload(
            x = x,
            y = y,
            z = z,
        )
    }

    private fun mapRotation(sample: CurrentTelemetrySample): RotationPayload? {
        val x = sample.rotationX ?: return null
        val y = sample.rotationY ?: return null
        val z = sample.rotationZ ?: return null
        return RotationPayload(
            x = x,
            y = y,
            z = z,
        )
    }

    private fun mapAttitude(sample: CurrentTelemetrySample): AttitudePayload? {
        val yaw = sample.yaw ?: return null
        val pitch = sample.pitch ?: return null
        val roll = sample.roll ?: return null
        return AttitudePayload(
            yaw = yaw,
            pitch = pitch,
            roll = roll,
        )
    }
}

/**
 * Заменить на ваш текущий domain/sample тип.
 *
 * Важно:
 * - timestampIso должен быть уже в UTC ISO-8601
 * - speedMS должен быть в m/s
 * - если часть сенсорных полей отсутствует, оставлять null
 */
interface CurrentTelemetrySample {
    val timestampIso: String
    val latitude: Double?
    val longitude: Double?
    val horizontalAccuracy: Double?
    val verticalAccuracy: Double?
    val speedMS: Double?
    val speedAccuracy: Double?
    val courseDeg: Double?
    val courseAccuracyDeg: Double?
    val accelX: Double?
    val accelY: Double?
    val accelZ: Double?
    val rotationX: Double?
    val rotationY: Double?
    val rotationZ: Double?
    val yaw: Double?
    val pitch: Double?
    val roll: Double?
    val aLongG: Double?
    val aLatG: Double?
    val aVertG: Double?
}