package com.alex.android_telemetry.telemetry.api.mapper

import com.alex.android_telemetry.telemetry.api.model.TelemetryEventPayload

class TelemetryEventPayloadMapper {

    fun map(event: CurrentTelemetryEvent): TelemetryEventPayload {
        return TelemetryEventPayload(
            type = event.type.toWireValue(),
            t = event.timestampIso,
            intensity = event.intensity,
            details = event.details,
            origin = event.origin ?: "client",
            algoVersion = event.algoVersion ?: "v2",
            speedMS = event.speedMS,
            eventClass = event.eventClass?.toWireValue(),
            subtype = event.subtype?.toWireValue(),
            severity = event.severity?.toWireValue(),
            metaJson = event.metaJson,
        )
    }
}

/**
 * Заменить на ваш текущий domain/event тип.
 */
interface CurrentTelemetryEvent {
    val type: CurrentTelemetryEventType
    val timestampIso: String
    val intensity: Double
    val details: String?
    val origin: String?
    val algoVersion: String?
    val speedMS: Double
    val eventClass: CurrentTelemetryEventClass?
    val subtype: CurrentRoadAnomalySubtype?
    val severity: CurrentRoadSeverity?
    val metaJson: String?
}

enum class CurrentTelemetryEventType {
    ACCEL,
    BRAKE,
    TURN,
    ACCEL_IN_TURN,
    BRAKE_IN_TURN,
    ROAD_ANOMALY,
}

enum class CurrentTelemetryEventClass {
    SHARP,
    EMERGENCY,
}

enum class CurrentRoadAnomalySubtype {
    POTHOLE,
    BUMP,
    SPEED_BUMP,
}

enum class CurrentRoadSeverity {
    LOW,
    HIGH,
}

private fun CurrentTelemetryEventType.toWireValue(): String {
    return when (this) {
        CurrentTelemetryEventType.ACCEL -> "accel"
        CurrentTelemetryEventType.BRAKE -> "brake"
        CurrentTelemetryEventType.TURN -> "turn"
        CurrentTelemetryEventType.ACCEL_IN_TURN -> "accel_in_turn"
        CurrentTelemetryEventType.BRAKE_IN_TURN -> "brake_in_turn"
        CurrentTelemetryEventType.ROAD_ANOMALY -> "road_anomaly"
    }
}

private fun CurrentTelemetryEventClass.toWireValue(): String {
    return when (this) {
        CurrentTelemetryEventClass.SHARP -> "sharp"
        CurrentTelemetryEventClass.EMERGENCY -> "emergency"
    }
}

private fun CurrentRoadAnomalySubtype.toWireValue(): String {
    return when (this) {
        CurrentRoadAnomalySubtype.POTHOLE -> "pothole"
        CurrentRoadAnomalySubtype.BUMP -> "bump"
        CurrentRoadAnomalySubtype.SPEED_BUMP -> "speed_bump"
    }
}

private fun CurrentRoadSeverity.toWireValue(): String {
    return when (this) {
        CurrentRoadSeverity.LOW -> "low"
        CurrentRoadSeverity.HIGH -> "high"
    }
}