package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class TelemetrySamplePayload(
    @SerialName("t") val t: String,
    @SerialName("lat") val lat: Double?,
    @SerialName("lon") val lon: Double?,
    @SerialName("speed_m_s") val speedMS: Double?
)
