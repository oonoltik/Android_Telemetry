package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class TelemetryEventPayload(
    @SerialName("type") val type: String,
    @SerialName("t") val t: String,
    @SerialName("intensity") val intensity: Double
)
