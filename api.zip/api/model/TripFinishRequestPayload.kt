package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class TripFinishRequestPayload(
    @SerialName("session_id") val sessionId: String,
    @SerialName("driver_id") val driverId: String,
    @SerialName("device_id") val deviceId: String,
    @SerialName("client_ended_at") val clientEndedAt: String
)
