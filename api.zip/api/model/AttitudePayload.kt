package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.Serializable

@Serializable
data class AttitudePayload(val yaw: Double, val pitch: Double, val roll: Double)
