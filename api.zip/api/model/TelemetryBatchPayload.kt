package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class TelemetryBatchPayload(
    @SerialName("device_id") val deviceId: String,
    @SerialName("driver_id") val driverId: String? = null,
    @SerialName("session_id") val sessionId: String,
    @SerialName("timestamp") val timestamp: String,
    @SerialName("batch_id") val batchId: String,
    @SerialName("batch_seq") val batchSeq: Int,
    @SerialName("samples") val samples: List<TelemetrySamplePayload>,
    @SerialName("events") val events: List<TelemetryEventPayload> = emptyList(),
)
