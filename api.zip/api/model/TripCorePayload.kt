package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.Serializable

@Serializable
data class TripCorePayload(
    val tripId: String,
    val sessionId: String
)
