package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.Serializable

@Serializable
data class RotationPayload(val x: Double, val y: Double, val z: Double)
