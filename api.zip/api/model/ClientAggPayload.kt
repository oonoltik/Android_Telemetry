package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.Serializable

@Serializable
data class ClientAggPayload(
    val count: Int,
    val sumIntensity: Double
)
