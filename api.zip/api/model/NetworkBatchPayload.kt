package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.Serializable

@Serializable
data class NetworkBatchPayload(
    val status: String? = null
)
