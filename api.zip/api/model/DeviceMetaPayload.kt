package com.alex.android_telemetry.telemetry.api.model

import kotlinx.serialization.Serializable

@Serializable
data class DeviceMetaPayload(
    val platform: String
)
