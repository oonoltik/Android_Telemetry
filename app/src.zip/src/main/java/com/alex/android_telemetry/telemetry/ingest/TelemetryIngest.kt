package com.company.app.telemetry.ingest

import com.company.app.telemetry.domain.model.TelemetryBatch

fun interface TelemetryBatchEnqueuer {
    suspend fun enqueue(batch: TelemetryBatch)
}
