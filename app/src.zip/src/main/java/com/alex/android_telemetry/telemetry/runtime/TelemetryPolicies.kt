package com.company.app.telemetry.domain.policy

import com.company.app.telemetry.domain.model.EventThresholdSet

interface EventThresholdResolver {
    fun getEffectiveThresholds(): EventThresholdSet
}

data class BatchFlushPolicy(
    val maxWindowMs: Long = 10_000,
    val maxFrames: Int = 50,
)
